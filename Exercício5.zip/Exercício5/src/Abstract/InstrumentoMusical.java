/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Abstract;

/**
 *
 * @author Administrator
 */
abstract class InstrumentoMusical {
    String Instrumento;

    public InstrumentoMusical(String Instrumento) {
        this.Instrumento = Instrumento;
    }
    
    
    abstract void tocar();
    
}
