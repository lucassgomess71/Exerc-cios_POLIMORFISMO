/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Abstract;

/**
 *
 * @author Administrator
 */
public class Piano extends InstrumentoMusical {

    public Piano(String Instrumento) {
        super(Instrumento);
    }
    

    @Override
    void tocar() {
        System.out.println("------Piano----------");
        System.out.println("Estou tocando " + Instrumento);               
    }
    
}
