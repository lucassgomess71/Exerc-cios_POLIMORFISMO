package Abstract;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Administrator
 */
public class MainAb {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       InstrumentoMusical Gui1 = new Guitarra("Guitarra");
       InstrumentoMusical Pi1 = new Piano("Piano");
       
       Gui1.tocar();
       Pi1.tocar();
    }
    
}
