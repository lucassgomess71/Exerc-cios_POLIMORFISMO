/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author Administrator
 */
public class MianIn {
    public static void main(String[] args) {
       InstrumentoMusical Gui1 = new Guitarra("Guitarra");
       InstrumentoMusical Pi1 = new Piano("Piano");
       
       Gui1.tocar();
       Pi1.tocar();
    }
}
    

