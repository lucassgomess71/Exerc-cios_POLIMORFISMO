/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstract4;

/**
 *
 * @author Admin
 */
class Gerente extends Funcionário {

    double salarioFixo;
    double bonus;

    Gerente (String nome, double salarioFixo, double bonus) {
        super(nome);
        this.salarioFixo = salarioFixo;
        this.bonus = bonus;
    }

    @Override
    void calcularSalario() {

        double salarioTotal = salarioFixo + bonus;

        System.out.println("Gerente: " + nome);
        System.out.println("Salario Gerente: " + salarioTotal);
    }
}

    