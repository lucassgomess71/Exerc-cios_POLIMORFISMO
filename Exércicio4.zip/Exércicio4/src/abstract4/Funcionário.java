/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstract4;

/**
 *
 * @author Admin
 */
abstract class Funcionário {
    String nome;

    public Funcionário(String nome) {
        this.nome = nome;
    }
   
    
    abstract void calcularSalario();
    
}
