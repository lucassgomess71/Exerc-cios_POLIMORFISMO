/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package abstract4;

/**
 *
 * @author Admin
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionário g1 = new Gerente("Lucas Gomes", 3200.00, 1000.00);
        Funcionário v1 = new Vendedor("Johw Santos", 1500.00, 250.00);
        
        g1.calcularSalario();
        v1.calcularSalario();
    }
    
}
