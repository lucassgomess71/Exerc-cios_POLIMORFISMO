/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstract4;

/**
 *
 * @author Admin
 */
class Vendedor extends Funcionário {

    double salarioBase;
    double comissao;

    Vendedor (String nome, double salarioBase, double comissao) {
        super(nome);
        this.salarioBase = salarioBase;
        this.comissao = comissao;
    }

    @Override
    void calcularSalario() {

        double salarioTotal = salarioBase + comissao;

        System.out.println("Vendendor: " + nome);
        System.out.println("Salario Vendedor: " + salarioTotal);
    }
}

