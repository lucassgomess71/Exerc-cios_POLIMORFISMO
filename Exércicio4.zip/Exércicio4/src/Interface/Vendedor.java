/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author Administrator
 */
public class Vendedor implements Funcionario {
    String nome;
    double salarioBase;
    double comissao;

    Vendedor (String nome, double salarioBase, double comissao) {
        this.nome = nome;
        this.salarioBase = salarioBase;
        this.comissao = comissao;
    }

    @Override
    public void calcularSalario() {

        double salarioTotal = salarioBase + comissao;

        System.out.println("Vendendor: " + nome);
        System.out.println("Salario Vendedor: " + salarioTotal);
    }
    
}
