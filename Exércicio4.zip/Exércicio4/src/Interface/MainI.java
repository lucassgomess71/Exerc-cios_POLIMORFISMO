/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author Administrator
 */
public class MainI {
    public static void main(String[] args) {
        Funcionario g1 = new Gerente("Lucas Gomes", 3200.00, 1000.00);
        Funcionario v1 = new Vendedor("Johw Santos", 1500.00, 250.00);
        
        g1.calcularSalario();
        v1.calcularSalario();
    }
    
}
    

