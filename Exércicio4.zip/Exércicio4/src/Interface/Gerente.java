/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author Admin
 */
 public class Gerente implements Funcionario {
    String nome;
    double salarioFixo;
    double bonus;

    Gerente (String nome, double salarioFixo, double bonus) {
        this.nome = nome;
        this.salarioFixo = salarioFixo;
        this.bonus = bonus;
    }

    @Override
    public void calcularSalario() {

        double salarioTotal = salarioFixo + bonus;
        
        System.out.println("--------INTERFACE-------------");
        System.out.println("Gerente: " + nome);
        System.out.println("Salario Gerente: " + salarioTotal);
    }
}
     
    

